/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 543:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(645);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".user-pronoun {\n  display: block;\n  line-height: 1.15rem;\n  height: 18px;\n  font-weight: bold;\n  font-size: 1rem;\n  padding: 4px;\n  padding-top: 3px;\n  background: var(--color-background-brand);\n  color: var(--color-hinted-grey-1);\n  border-radius: 3px;\n}\n.tw-root--theme-light .user-pronoun {\n  background: var(--color-hinted-grey-12);\n}\n.pr-badge-wrapper[data-a-target=\"pr-badge-cnt\"][data-provider=\"pronouns.alejo.io\"] {\n  float: left;\n  position: relative;\n  margin-right: 0.325rem;\n  margin-top: 0.15rem;\n}\n.pr-badge-wrapper:hover > .pr-tooltip {\n  display: block;\n}\n.pr-tooltip {\n  padding: 3px 6px;\n  border-radius: var(--border-radius-medium);\n  background-color: var(--color-background-tooltip);\n  color: var(--color-text-tooltip);\n  display: none;\n  position: absolute;\n  font-size: var(--font-size-6);\n  font-weight: var(--font-weight-semibold);\n  line-height: var(--line-height-heading);\n  text-align: left;\n  z-index: var(--z-index-balloon);\n  pointer-events: none;\n  user-select: none;\n  white-space: nowrap;\n  top: auto;\n  bottom: 100%;\n  left: 0px;\n  margin-bottom: 0.9rem;\n}\n.pr-tooltip::before {\n  top: -6px;\n  left: -6px;\n  width: calc(100% + 12px);\n  height: calc(100% + 12px);\n  z-index: var(--z-index-below);\n}\n.pr-tooltip::after {\n  background-color: var(--color-background-tooltip);\n  width: 6px;\n  height: 6px;\n  transform: rotate(45deg);\n  z-index: var(--z-index-below);\n  bottom: -3px;\n  left: 6px;\n}\n.pr-tooltip::before,\n.pr-tooltip::after {\n  position: absolute;\n  content: \"\";\n}\n#pr-streamer-tag {\n  margin-right: 0.5rem !important;\n}\n.pronoundb-chat-badge {\n  float: left;\n  position: initial;\n  margin-right: 0.325rem !important;\n  margin-top: 0.15rem !important;\n  bottom: auto !important;\n  height: 18px !important;\n  line-height: 1.15rem !important;\n  font-weight: bold !important;\n  font-size: 1rem !important;\n  padding: 4px !important;\n  padding-top: 3px !important;\n  background: var(--color-background-brand) !important;\n  color: var(--color-hinted-grey-1) !important;\n  border-radius: 3px !important;\n}\n.tw-root--theme-light .pronoundb-chat-badge {\n  background: var(--color-hinted-grey-12) !important;\n}\n", ""]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ 645:
/***/ ((module) => {



/*
  MIT License http://www.opensource.org/licenses/mit-license.php
  Author Tobias Koppers @sokra
*/
// css base code, injected by the css-loader
// eslint-disable-next-line func-names
module.exports = function (cssWithMappingToString) {
  var list = []; // return the list of modules as css string

  list.toString = function toString() {
    return this.map(function (item) {
      var content = cssWithMappingToString(item);

      if (item[2]) {
        return "@media ".concat(item[2], " {").concat(content, "}");
      }

      return content;
    }).join("");
  }; // import a list of modules into the list
  // eslint-disable-next-line func-names


  list.i = function (modules, mediaQuery, dedupe) {
    if (typeof modules === "string") {
      // eslint-disable-next-line no-param-reassign
      modules = [[null, modules, ""]];
    }

    var alreadyImportedModules = {};

    if (dedupe) {
      for (var i = 0; i < this.length; i++) {
        // eslint-disable-next-line prefer-destructuring
        var id = this[i][0];

        if (id != null) {
          alreadyImportedModules[id] = true;
        }
      }
    }

    for (var _i = 0; _i < modules.length; _i++) {
      var item = [].concat(modules[_i]);

      if (dedupe && alreadyImportedModules[item[0]]) {
        // eslint-disable-next-line no-continue
        continue;
      }

      if (mediaQuery) {
        if (!item[2]) {
          item[2] = mediaQuery;
        } else {
          item[2] = "".concat(mediaQuery, " and ").concat(item[2]);
        }
      }

      list.push(item);
    }
  };

  return list;
};

/***/ }),

/***/ 379:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {



var isOldIE = function isOldIE() {
  var memo;
  return function memorize() {
    if (typeof memo === 'undefined') {
      // Test for IE <= 9 as proposed by Browserhacks
      // @see http://browserhacks.com/#hack-e71d8692f65334173fee715c222cb805
      // Tests for existence of standard globals is to allow style-loader
      // to operate correctly into non-standard environments
      // @see https://github.com/webpack-contrib/style-loader/issues/177
      memo = Boolean(window && document && document.all && !window.atob);
    }

    return memo;
  };
}();

var getTarget = function getTarget() {
  var memo = {};
  return function memorize(target) {
    if (typeof memo[target] === 'undefined') {
      var styleTarget = document.querySelector(target); // Special case to return head of iframe instead of iframe itself

      if (window.HTMLIFrameElement && styleTarget instanceof window.HTMLIFrameElement) {
        try {
          // This will throw an exception if access to iframe is blocked
          // due to cross-origin restrictions
          styleTarget = styleTarget.contentDocument.head;
        } catch (e) {
          // istanbul ignore next
          styleTarget = null;
        }
      }

      memo[target] = styleTarget;
    }

    return memo[target];
  };
}();

var stylesInDom = [];

function getIndexByIdentifier(identifier) {
  var result = -1;

  for (var i = 0; i < stylesInDom.length; i++) {
    if (stylesInDom[i].identifier === identifier) {
      result = i;
      break;
    }
  }

  return result;
}

function modulesToDom(list, options) {
  var idCountMap = {};
  var identifiers = [];

  for (var i = 0; i < list.length; i++) {
    var item = list[i];
    var id = options.base ? item[0] + options.base : item[0];
    var count = idCountMap[id] || 0;
    var identifier = "".concat(id, " ").concat(count);
    idCountMap[id] = count + 1;
    var index = getIndexByIdentifier(identifier);
    var obj = {
      css: item[1],
      media: item[2],
      sourceMap: item[3]
    };

    if (index !== -1) {
      stylesInDom[index].references++;
      stylesInDom[index].updater(obj);
    } else {
      stylesInDom.push({
        identifier: identifier,
        updater: addStyle(obj, options),
        references: 1
      });
    }

    identifiers.push(identifier);
  }

  return identifiers;
}

function insertStyleElement(options) {
  var style = document.createElement('style');
  var attributes = options.attributes || {};

  if (typeof attributes.nonce === 'undefined') {
    var nonce =  true ? __webpack_require__.nc : 0;

    if (nonce) {
      attributes.nonce = nonce;
    }
  }

  Object.keys(attributes).forEach(function (key) {
    style.setAttribute(key, attributes[key]);
  });

  if (typeof options.insert === 'function') {
    options.insert(style);
  } else {
    var target = getTarget(options.insert || 'head');

    if (!target) {
      throw new Error("Couldn't find a style target. This probably means that the value for the 'insert' parameter is invalid.");
    }

    target.appendChild(style);
  }

  return style;
}

function removeStyleElement(style) {
  // istanbul ignore if
  if (style.parentNode === null) {
    return false;
  }

  style.parentNode.removeChild(style);
}
/* istanbul ignore next  */


var replaceText = function replaceText() {
  var textStore = [];
  return function replace(index, replacement) {
    textStore[index] = replacement;
    return textStore.filter(Boolean).join('\n');
  };
}();

function applyToSingletonTag(style, index, remove, obj) {
  var css = remove ? '' : obj.media ? "@media ".concat(obj.media, " {").concat(obj.css, "}") : obj.css; // For old IE

  /* istanbul ignore if  */

  if (style.styleSheet) {
    style.styleSheet.cssText = replaceText(index, css);
  } else {
    var cssNode = document.createTextNode(css);
    var childNodes = style.childNodes;

    if (childNodes[index]) {
      style.removeChild(childNodes[index]);
    }

    if (childNodes.length) {
      style.insertBefore(cssNode, childNodes[index]);
    } else {
      style.appendChild(cssNode);
    }
  }
}

function applyToTag(style, options, obj) {
  var css = obj.css;
  var media = obj.media;
  var sourceMap = obj.sourceMap;

  if (media) {
    style.setAttribute('media', media);
  } else {
    style.removeAttribute('media');
  }

  if (sourceMap && typeof btoa !== 'undefined') {
    css += "\n/*# sourceMappingURL=data:application/json;base64,".concat(btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap)))), " */");
  } // For old IE

  /* istanbul ignore if  */


  if (style.styleSheet) {
    style.styleSheet.cssText = css;
  } else {
    while (style.firstChild) {
      style.removeChild(style.firstChild);
    }

    style.appendChild(document.createTextNode(css));
  }
}

var singleton = null;
var singletonCounter = 0;

function addStyle(obj, options) {
  var style;
  var update;
  var remove;

  if (options.singleton) {
    var styleIndex = singletonCounter++;
    style = singleton || (singleton = insertStyleElement(options));
    update = applyToSingletonTag.bind(null, style, styleIndex, false);
    remove = applyToSingletonTag.bind(null, style, styleIndex, true);
  } else {
    style = insertStyleElement(options);
    update = applyToTag.bind(null, style, options);

    remove = function remove() {
      removeStyleElement(style);
    };
  }

  update(obj);
  return function updateStyle(newObj) {
    if (newObj) {
      if (newObj.css === obj.css && newObj.media === obj.media && newObj.sourceMap === obj.sourceMap) {
        return;
      }

      update(obj = newObj);
    } else {
      remove();
    }
  };
}

module.exports = function (list, options) {
  options = options || {}; // Force single-tag solution on IE6-9, which has a hard limit on the # of <style>
  // tags it will allow on a page

  if (!options.singleton && typeof options.singleton !== 'boolean') {
    options.singleton = isOldIE();
  }

  list = list || [];
  var lastIdentifiers = modulesToDom(list, options);
  return function update(newList) {
    newList = newList || [];

    if (Object.prototype.toString.call(newList) !== '[object Array]') {
      return;
    }

    for (var i = 0; i < lastIdentifiers.length; i++) {
      var identifier = lastIdentifiers[i];
      var index = getIndexByIdentifier(identifier);
      stylesInDom[index].references--;
    }

    var newLastIdentifiers = modulesToDom(newList, options);

    for (var _i = 0; _i < lastIdentifiers.length; _i++) {
      var _identifier = lastIdentifiers[_i];

      var _index = getIndexByIdentifier(_identifier);

      if (stylesInDom[_index].references === 0) {
        stylesInDom[_index].updater();

        stylesInDom.splice(_index, 1);
      }
    }

    lastIdentifiers = newLastIdentifiers;
  };
};

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			id: moduleId,
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {

;// CONCATENATED MODULE: ./src/ts/logger.ts
var LoggerLevel;
(function (LoggerLevel) {
    LoggerLevel[LoggerLevel["NONE"] = 0] = "NONE";
    LoggerLevel[LoggerLevel["INFO"] = 1] = "INFO";
    LoggerLevel[LoggerLevel["WARN"] = 2] = "WARN";
    LoggerLevel[LoggerLevel["DEBUG"] = 3] = "DEBUG";
})(LoggerLevel || (LoggerLevel = {}));
class Logger {
    constructor(level, outputCommand) {
        this.level = level;
        if (outputCommand !== undefined) {
            this.outputCommand = outputCommand;
        }
        else {
            this.outputCommand = console.log;
        }
    }
    log(level, ...args) {
        if (this.level === LoggerLevel.NONE) {
            return;
        }
        else if (this.level >= level) {
            this.outputCommand(...args);
        }
    }
    info(...args) {
        this.log(LoggerLevel.INFO, ...args);
    }
    warn(...args) {
        this.log(LoggerLevel.WARN, ...args);
    }
    debug(...args) {
        this.log(LoggerLevel.DEBUG, ...args);
    }
}
let DefaultLogger = new Logger(LoggerLevel.NONE);
/* harmony default export */ const logger = (DefaultLogger);

;// CONCATENATED MODULE: ./src/ts/api/pronouns.alejo.io.ts
async function get(endpoint) {
    return await fetch("https://pronouns.alejo.io/api/" + endpoint).then(async (res) => {
        return res.json();
    });
}
async function getPronouns() {
    var res = await get("pronouns");
    var p = {};
    res.forEach((pronoun) => {
        p[pronoun.name] = pronoun.display;
    });
    return p;
}
async function getUserPronounKey(username) {
    if (username.length < 1) {
        return;
    }
    var res = await get("users/" + username);
    let match = res.find((user) => {
        return user.login.toLowerCase() === username.toLowerCase();
    });
    if (match !== undefined) {
        return match.pronoun_id;
    }
}

;// CONCATENATED MODULE: ./src/ts/pronouns.ts

let pronouns;
const setPronouns = (value) => {
    pronouns = value;
};
const pronouns_getPronouns = () => {
    return pronouns;
};
const initPronouns = async () => {
    const pronouns = await getPronouns();
    setPronouns(pronouns);
};
const getUserPronoun = async (username) => {
    const pronouns = pronouns_getPronouns();
    const pronounKey = await getUserPronounKey(username);
    if (!pronouns || !pronounKey || !pronouns.hasOwnProperty(pronounKey)) {
        return;
    }
    const pronoun = pronouns[pronounKey];
    return pronoun;
};

;// CONCATENATED MODULE: ./src/ts/constants/selectors.ts
const ROOT = `#root`;
const LIVE_CHAT_DISPLAY_NAME = `span.chat-author__display-name`;
const LIVE_CHAT_BADGES = `.chat-line__username-container > span:not(.chat-line__username)`;
const VOD_CHAT_USERNAME = `[data-test-selector="comment-author-selector"]`;
const VOD_CHAT_BADGES = `[data-test-selector="message-layout"] span`;
const FFZ = {
    LIVE_CHAT_DISPLAY_NAME: `span.chat-line__username`,
    LIVE_CHAT_BADGES: `span.chat-line__message--badges`,
};

;// CONCATENATED MODULE: ./src/ts/pronounBadge.ts
function generatePronounBadge(text) {
    let textSpan = document.createElement('span');
    {
        textSpan.setAttribute('class', 'user-pronoun');
        textSpan.setAttribute('data-a-target', 'pr-badge-txt');
        textSpan.textContent = text;
    }
    let tooltipElm = document.createElement('div');
    {
        tooltipElm.setAttribute('class', 'pr-tooltip');
        tooltipElm.setAttribute('data-a-target', 'pr-badge-tt');
        tooltipElm.setAttribute('role', 'tooltip');
        tooltipElm.textContent = 'Pronoun(s)';
    }
    let badgeDiv = document.createElement('div');
    {
        badgeDiv.setAttribute('class', 'pr-badge-wrapper');
        badgeDiv.setAttribute('data-a-target', 'pr-badge-cnt');
        badgeDiv.setAttribute('data-provider', 'pronouns.alejo.io');
        badgeDiv.append(textSpan, tooltipElm);
    }
    return badgeDiv;
}

;// CONCATENATED MODULE: ./src/ts/messageProcessor.ts



const tagAsProcessed = (target) => {
    if (target.getAttribute('pronouns') === null) {
        target.setAttribute('pronouns', '');
        return false;
    }
    else {
        return true;
    }
};
const processVoDMessage = async (target) => {
    if (tagAsProcessed(target)) {
        return target;
    }
    const userElm = target.querySelector(VOD_CHAT_USERNAME);
    if (!userElm) {
        return target;
    }
    const badges = target.querySelector(VOD_CHAT_BADGES);
    if (!badges) {
        return target;
    }
    const username = userElm.getAttribute('data-a-user') || userElm.textContent;
    if (!username) {
        return target;
    }
    const userPronoun = await getUserPronoun(username);
    if (!userPronoun) {
        return target;
    }
    badges.prepend(generatePronounBadge(userPronoun));
    return target;
};
const processLiveMessage = async (target) => {
    if (tagAsProcessed(target)) {
        return target;
    }
    const userElm = target.querySelector(LIVE_CHAT_DISPLAY_NAME) || target.querySelector(FFZ.LIVE_CHAT_DISPLAY_NAME);
    if (!userElm) {
        return target;
    }
    const badges = target.querySelector(`${LIVE_CHAT_BADGES},${FFZ.LIVE_CHAT_BADGES}`);
    if (!badges) {
        return target;
    }
    const username = userElm.getAttribute('data-a-user') || userElm.textContent;
    if (!username) {
        return target;
    }
    const userPronoun = await getUserPronoun(username);
    if (!userPronoun) {
        return target;
    }
    badges.prepend(generatePronounBadge(userPronoun));
    return target;
};

;// CONCATENATED MODULE: ./src/ts/streamerProcesser.ts

const PRONOUNS_TAG_ELEMENT_ID = "pr-streamer-tag";
const getPronounsElement = () => {
    return document.getElementById(PRONOUNS_TAG_ELEMENT_ID);
};
/*
    We look for:
    + It's a link <a>
    + The tw-tag class
    + A link to a tag page
*/
const TAG_LINK_SELECTOR = "a.tw-tag[href*='/tags/']";
const getAllTagLinkElements = () => {
    return [...document.querySelectorAll(TAG_LINK_SELECTOR)];
};
const getTagLinkElement = () => {
    return document.querySelector(TAG_LINK_SELECTOR);
};
let haveTagElementsLoaded = false;
const setHaveTagElementsLoaded = (value) => {
    haveTagElementsLoaded = value;
};
const getHaveTagElementsLoaded = () => {
    return haveTagElementsLoaded;
};
const onTagElementsLoaded = (callback) => {
    if (getHaveTagElementsLoaded()) {
        return;
    }
    const pronounsTagElement = getPronounsElement();
    const tagLinkElement = getTagLinkElement();
    if (pronounsTagElement || tagLinkElement) {
        setHaveTagElementsLoaded(true);
        callback();
        return;
    }
};
const getUsername = () => {
    const pathnameParts = window.location.pathname.split('/');
    if (pathnameParts.length < 2) {
        return;
    }
    const username = pathnameParts[1].toLowerCase();
    return username;
};
const validateTagMarkup = (tagLinkElement) => {
    const [tagLinkSpacingElement] = tagLinkElement.childNodes;
    if (!tagLinkSpacingElement) {
        return false;
    }
    const tagElement = tagLinkElement.parentElement;
    if (!tagElement) {
        return false;
    }
    return true;
};
const createNewTagElement = (tagElement, pronoun, username) => {
    const newTagElement = tagElement.cloneNode(true); // true copies all parts of element
    newTagElement.id = PRONOUNS_TAG_ELEMENT_ID;
    newTagElement.setAttribute('data-pronouns-username', username);
    const [newTagLinkElement] = newTagElement.childNodes;
    newTagLinkElement.setAttribute('aria-label', pronoun);
    newTagLinkElement.setAttribute('data-a-target', pronoun);
    newTagLinkElement.href = 'https://pronouns.alejo.io/';
    const [newTagLinkSpacingElement] = newTagLinkElement.childNodes;
    if (newTagLinkSpacingElement) {
        newTagLinkSpacingElement.innerText = pronoun;
    }
    return newTagElement;
};
const processStreamerPronounsTag = async () => {
    const username = getUsername();
    if (!username) {
        return;
    }
    const pronounsTagElement = getPronounsElement();
    if (pronounsTagElement?.getAttribute('data-pronouns-username') === 'username') {
        return;
    }
    if (pronounsTagElement) {
        // remove any tag for other users
        pronounsTagElement.remove();
    }
    const tagLinkElement = getTagLinkElement();
    if (!tagLinkElement) {
        return;
    }
    if (!validateTagMarkup(tagLinkElement)) {
        return;
    }
    // the link is wrapped in some padding, lets get that element
    const tagElement = tagLinkElement.parentElement;
    const pronoun = await getUserPronoun(username);
    if (!pronoun) {
        return;
    }
    // you can add tags manually in twitch
    const hasPronounTagAlready = getAllTagLinkElements().map((a) => a.innerText.toLowerCase()).includes(pronoun.toLowerCase());
    if (hasPronounTagAlready) {
        return;
    }
    const newTagElement = createNewTagElement(tagElement, pronoun, username);
    // add to tags container in the page
    const tagContainer = tagElement.parentElement;
    tagContainer.prepend(newTagElement);
};

// EXTERNAL MODULE: ./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js
var injectStylesIntoStyleTag = __webpack_require__(379);
var injectStylesIntoStyleTag_default = /*#__PURE__*/__webpack_require__.n(injectStylesIntoStyleTag);
// EXTERNAL MODULE: ./node_modules/css-loader/dist/cjs.js!./node_modules/less-loader/dist/cjs.js!./src/style/content.less
var content = __webpack_require__(543);
;// CONCATENATED MODULE: ./src/style/content.less

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = injectStylesIntoStyleTag_default()(content/* default */.Z, options);



/* harmony default export */ const style_content = (content/* default.locals */.Z.locals || {});
;// CONCATENATED MODULE: ./src/ts/index.ts
/* jshint esversion: 8 */






const isVoD = () => /^\/videos\/\d+/.test(window.location.pathname);
const nodeParser = (node) => {
    if (node instanceof HTMLElement) {
        logger.debug(node);
        if (node.getAttribute("data-test-selector") === "chat-line-message" || node.classList.contains('chat-line__message')) {
            processLiveMessage(node);
        }
        else if (node.classList.contains("chat-line__message--badges") && node.parentElement) {
            processLiveMessage(node.parentNode);
        }
        else if (isVoD() && node.nodeName.toUpperCase() === "LI") {
            processVoDMessage(node);
        }
    }
};
let lastUrl = window.location.href;
const handleURLChanges = () => {
    const url = window.location.href;
    if (url !== lastUrl) {
        lastUrl = url;
        setHaveTagElementsLoaded(false);
    }
};
const mutationCallback = (mutations) => {
    handleURLChanges();
    mutations.forEach((mutation) => {
        if (!mutation.addedNodes || mutation.addedNodes.length === 0) {
            return;
        }
        onTagElementsLoaded(() => {
            processStreamerPronounsTag();
        });
        const hasApplicationLoaded = !!document.querySelector(ROOT);
        if (hasApplicationLoaded) {
            mutation.addedNodes.forEach(nodeParser);
        }
    });
};
const init = async () => {
    logger.info('Fetching pronouns');
    await initPronouns();
    logger.info('Fetched pronouns');
    const observer = new MutationObserver(mutationCallback);
    const config = { childList: true, subtree: true };
    observer.observe(document.body, config);
};
init();

})();

/******/ })()
;